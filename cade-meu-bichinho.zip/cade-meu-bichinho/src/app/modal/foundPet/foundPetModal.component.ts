import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDatepickerModule,
         MatNativeDateModule,MatButtonModule,MatButtonToggleModule,
         MatIconModule,MatIconRegistry,MatTooltipModule} 
         from '@angular/material'; 
import {DomSanitizer} from '@angular/platform-browser';;
import {HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
import {FormBuilder,FormControl, FormGroup,Validators} from '@angular/forms';

import { ServiceComponent } from '../../service.component';

@Component({
  selector: 'found-pet-modal',
  templateUrl: './foundPetModal.component.html',
  styleUrls: ['./foundPetModal.component.scss']
})
export class FoundPetModalComponent { 
  formPetFound: FormGroup;
  selectedSpecie= 0;
  selectedSex= 0;
  selectedLifeStage= 0;
  selectedFurColor= 0; 
  photoData;
  photoWithoutHeader64;
  phoneWithWhats=false; 
  selectedImg = true;

  constructor(
    private dialogRef: MatDialogRef<FoundPetModalComponent>,
    private formBuilder: FormBuilder,
    private service: ServiceComponent,
    ){ 

    this.formPetFound = this.formBuilder.group({
      name: ['Nome desconhecido', Validators.required],
      phone: ['', Validators.required],
      description: ['', Validators.required],
      photoSrc: ['',Validators.required]   
    });
  }

  // talvez eu precise: {value: '', disabled: true}

  get form() {
    return this.formPetFound.controls;
  }
  
  // Set date of day 
  //**TO DO: ARRUMAR FORMATO!
  date = new FormControl(new Date());
  serializedDate = new FormControl((new Date()).toISOString());

 
  save() { 
    alert(this.form.name.value);
    alert(this.selectedSpecie);
    alert(this.date.value);
    alert(this.form.phone.value);
    alert(this.form.description.value);
  }

  close() {
    //**TO DO: Pedir confirmação antes!! 
    this.dialogRef.close();
  }

  isPhoneWithWhats() { 
   if(this.phoneWithWhats){  
      this.phoneWithWhats = false; 
   }else{
     this.phoneWithWhats = true; 
   }    
  }


  onFileSelected(event){
    const target= event.target as HTMLInputElement;
    var file: File = (target.files as FileList)[0];    
    this.form.photoSrc.setValue(file.name);
   
    var myReader:FileReader = new FileReader();
    myReader.onloadend = (e) => {
      this.photoData = myReader.result; 
    }
   
    myReader.readAsDataURL(file); 
  }

  //TO DO oordenadas
  addPet(){
   console.log(this.formPetFound.valid);

     if(this.formPetFound.valid){
      this.photoWithoutHeader64 = this.photoData.split(',')[1]; 
      
      let pet = {
         "name": this.form.name.value, 
         "specie": this.selectedSpecie,
         "sex": this.selectedSex,
         "furColor": this.selectedFurColor,
         "lifeStage": this.selectedLifeStage,
         "photo" : this.photoWithoutHeader64, 
         "date" : this.date.value,
         "latitude" : "-30.032616",
         "longitude" : "-51.231016",
         "phone" : this.form.phone.value,
         "phoneWithWhats" :  this.phoneWithWhats,
         "description" : this.form.description.value,
         "lostPet" : "false"
      }
      
      this.service.addPet(pet).subscribe(
            (data:any)=> {
                console.log(data);
                alert("pera");
            },
            error => {
                console.log(error);
            });
    }
  }

}

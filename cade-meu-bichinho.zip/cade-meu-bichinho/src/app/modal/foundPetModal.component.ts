import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDatepickerModule,
         MatNativeDateModule,MatButtonModule,MatButtonToggleModule,
         MatIconModule,MatIconRegistry,MatTooltipModule} 
         from '@angular/material'; 
import {DomSanitizer} from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'found-pet-modal',
  templateUrl: './foundPetModal.component.html',
  styleUrls: ['./foundPetModal.component.scss']
})
export class FoundPetModalComponent { 
  description: string;

  constructor(
    private dialogRef: MatDialogRef<FoundPetModalComponent>) {

      
  }
 
  save() { 
    this.dialogRef.close();
  }

  close() {
    this.dialogRef.close();
  }


  getFile(){
    var text = (document.getElementById("file-input") as HTMLInputElement);
    var src = (document.getElementById("file-src") as HTMLInputElement);
    src.value = text.value;
  }
}

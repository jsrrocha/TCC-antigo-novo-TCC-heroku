import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef,MatDatepickerModule,
MatNativeDateModule} from '@angular/material';


@Component({
  selector: 'comment-modal',
  templateUrl: './commentModal.component.html',
  styleUrls: ['./commentModal.component.scss'] 
  
})
export class CommentModalComponent {

  description: string;
  constructor(
    private dialogRef: MatDialogRef<CommentModalComponent>,
  ) {}

  

  save() {
    this.dialogRef.close();
  }

  close() {
    this.dialogRef.close();
  }
}

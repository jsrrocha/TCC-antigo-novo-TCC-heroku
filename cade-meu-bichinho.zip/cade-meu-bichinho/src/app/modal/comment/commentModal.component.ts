import { Component, Inject } from '@angular/core';
import {HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
import {FormBuilder,FormControl, FormGroup,Validators} from '@angular/forms';

import {DateAdapter, MAT_DATE_FORMATS,MAT_DATE_LOCALE} from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';

//material
import { MAT_DIALOG_DATA, MatDialogRef,MatDatepickerModule,
MatNativeDateModule} from '@angular/material';

// Components
import { ServiceComponent } from '../../service.component';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY',
  },
};


@Component({
  selector: 'comment-modal',
  templateUrl: './commentModal.component.html',
  styleUrls: ['./commentModal.component.scss'],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ], 
  
})
export class CommentModalComponent {
  formComment: FormGroup;
  phoneWithWhats=false; 


  constructor(
    private dialogRef: MatDialogRef<CommentModalComponent>,
    private formBuilder: FormBuilder,
    private service: ServiceComponent,
    ){

    this.formComment = this.formBuilder.group({
      name: ['', Validators.required],
      phone: ['', Validators.required],
      comment: ['', Validators.required]
    });
  }

  get form() {
    return this.formComment.controls;
  }

  // Set date of day 
  date = new FormControl(new Date());
  serializedDate = new FormControl((new Date()).toISOString());

   isPhoneWithWhats() { 
   if(this.phoneWithWhats){  
      this.phoneWithWhats = false; 
   }else{
     this.phoneWithWhats = true; 
   }    
  }

  addComment(){
     //ARRUMAR ID PET E IDS USER,NOME E TELEFONE VIRAO DO USER! VER..
     if(this.formComment.valid){      
      let comment = {
         "name": this.form.name.value, 
         "date" : this.date.value,
         "phone" : this.form.phone.value,
         "phoneWithWhats" :  this.phoneWithWhats,
         "comment" : this.form.comment.value,
         "idPet": "2", 
         "idReceived": "1",
         "idSend": "1"
      }
      
      this.service.addComment(comment).subscribe(
            (data:any)=> {
                console.log(data);
                this.dialogRef.close();

            },
            error => {
                console.log(error);
            });
    }
  }


  close() {
    this.dialogRef.close();
  }
}

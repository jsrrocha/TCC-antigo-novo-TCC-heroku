import { Component, Inject } from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';;
import {HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
import {FormBuilder,FormControl, FormGroup,Validators} from '@angular/forms';
import {DateAdapter, MAT_DATE_FORMATS,MAT_DATE_LOCALE} from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';

//material
import { MAT_DIALOG_DATA, MatDialogRef, MatDatepickerModule,
         MatNativeDateModule,MatButtonModule,MatButtonToggleModule,
         MatIconModule,MatIconRegistry,MatTooltipModule} 
         from '@angular/material'; 

//component
import { ServiceComponent } from '../../service.component';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY',
  },
};

@Component({
  selector: 'lost-pet-modal',
  templateUrl: './lostPetModal.component.html',
  styleUrls: ['./lostPetModal.component.scss'],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})
export class LostPetModalComponent {
  formPetLost: FormGroup;
  selectedSpecie= 0;
  selectedSex= 0;
  selectedLifeStage= 0;
  selectedFurColor= 0; 
  photoData;
  photoWithoutHeader64;
  phoneWithWhats=false; 
  selectedImg = true;

  constructor(
    private dialogRef: MatDialogRef<LostPetModalComponent>,
    private formBuilder: FormBuilder,
    private service: ServiceComponent,
    ){ 

    this.formPetLost = this.formBuilder.group({
      name: ['', Validators.required], 
      phone: ['', Validators.required],
      description: ['', Validators.required], //**NAO TA APARECENDO O VERMELHO DE REQUI
      photoSrc: ['',Validators.required]   
    });
  }

  get form() {
    return this.formPetLost.controls;
  }
  
  // Set date of day 
  date = new FormControl(new Date());
  serializedDate = new FormControl((new Date()).toISOString());

  save() { 
    alert(this.form.name.value);
    alert(this.selectedSpecie);
    alert(this.date.value);
    alert(this.form.phone.value);
    alert(this.form.description.value);
  }

  close() {
    //**TO DO: Pedir confirmação antes!! 
    this.dialogRef.close();
  }

  isPhoneWithWhats() { 
   if(this.phoneWithWhats){  
      this.phoneWithWhats = false; 
   }else{
     this.phoneWithWhats = true; 
   }    
  }

  onFileSelected(event){
    const target= event.target as HTMLInputElement;
    var file: File = (target.files as FileList)[0];    
    this.form.photoSrc.setValue(file.name);
   
    var myReader:FileReader = new FileReader();
    myReader.onloadend = (e) => {
      this.photoData = myReader.result; 
    }
   
    myReader.readAsDataURL(file); 
  }

  //TO DO oordenadas
  addPet(){
   console.log(this.formPetLost.valid);

     if(this.formPetLost.valid){
      this.photoWithoutHeader64 = this.photoData.split(',')[1]; 
      
      let pet = {
         "name": this.form.name.value, 
         "specie": this.selectedSpecie,
         "sex": this.selectedSex,
         "furColor": this.selectedFurColor,
         "lifeStage": this.selectedLifeStage,
         "photo" : this.photoWithoutHeader64, 
         "date" : this.date.value,
         "latitude" : "-30.032616",
         "longitude" : "-51.231016",
         "phone" : this.form.phone.value,
         "phoneWithWhats" :  this.phoneWithWhats,
         "description" : this.form.description.value,
         "lostPet" : "true"
      }
      
      this.service.addPet(pet).subscribe(
            (data:any)=> {
                console.log(data);
                this.dialogRef.close();
            },
            error => {
                console.log(error);
            });
    }
  }
}

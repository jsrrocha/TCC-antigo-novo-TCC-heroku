import { Component, Inject } from '@angular/core';
import {HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
import {FormBuilder,FormControl, FormGroup,Validators} from '@angular/forms';

//material

import { MAT_DIALOG_DATA, MatDialogRef,MatDialogConfig,MatDialog,
         MatButtonModule,MatButtonToggleModule,
         MatIconModule,MatIconRegistry,MatTooltipModule} 
         from '@angular/material'; 

// Components
import { RegisterModalComponent } from '../../modal/register/registerModal.component';  

import { RegisterNewPasswordModalComponent } from '../../modal/registerNewPassword/registerNewPasswordModal.component'; 


import { ServiceComponent } from '../../service.component';
import { TokenInterceptor } from '../../token.interceptor';   


@Component({
  selector: 'login-modal',
  templateUrl: './loginModal.component.html',
  styleUrls: ['./loginModal.component.scss']
})
export class LoginModalComponent { 

  formLogin: FormGroup;
  phoneWithWhats=false; 
  
  constructor(
    private dialogRef: MatDialogRef<LoginModalComponent>,
    private formBuilder: FormBuilder,
    private service: ServiceComponent,
    private dialog: MatDialog, 
    ){
    
    this.formLogin = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['',Validators.required]   
    });

  }

  get formControl() {
    return this.formLogin.controls;
  }

  isPhoneWithWhats() { 
   if(this.phoneWithWhats){  
      this.phoneWithWhats = false; 
   }else{
     this.phoneWithWhats = true; 
   }    
  }  

  loginAuth(){
    if(this.formLogin.valid){
      localStorage.setItem('token',this.service.tokenForClient);

      this.service.authentication(this.formControl.email.value,this.formControl.password.value)
      .subscribe(
      (data:any)=> {
          console.log(data);
          localStorage.setItem('token','Bearer ' + data.access_token);
          localStorage.setItem('refreshToken',data.refresh_token);
          localStorage.setItem('expiresIn',data.expires_in);

          this.dialogRef.close();
        
      },
      error => {
          console.error(error);
      });
    }
  }

  refreshAccessAuth(){
    localStorage.setItem('token',this.service.tokenForClient);

    this.service.refreshToken(localStorage.getItem('refreshToken'))
    .subscribe(
    (data:any)=> {
        console.log(data);
        localStorage.setItem('token','Bearer ' + data.access_token);
        localStorage.setItem('refreshToken',data.refresh_token);
        localStorage.setItem('expiresIn',data.expires_in);
    },
    error => {
        console.error(error);
    });
  }
  

  close() {
    //**TO DO: Pedir confirmação antes!! 
    this.dialogRef.close();
  }

  openDialogRegister() {
    this.close();

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '250px';
    dialogConfig.height = '350px'; 
    this.dialog.open(RegisterModalComponent, dialogConfig);
    
  }



  openDialogRegisterNewPassword() {
    this.close();

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '250px';
    dialogConfig.height = '350px';  

    this.dialog.open(RegisterNewPasswordModalComponent, dialogConfig);
  }

}

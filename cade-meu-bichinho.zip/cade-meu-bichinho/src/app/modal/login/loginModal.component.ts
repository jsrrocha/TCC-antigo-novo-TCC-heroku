import { Component, Inject } from '@angular/core';
import {HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
import {FormBuilder,FormControl, FormGroup,Validators} from '@angular/forms';

//material
import { MAT_DIALOG_DATA, MatDialogRef,
         MatButtonModule,MatButtonToggleModule,
         MatIconModule,MatIconRegistry,MatTooltipModule} 
         from '@angular/material'; 

// Components
import { ServiceComponent } from '../../service.component';

@Component({
  selector: 'login-modal',
  templateUrl: './loginModal.component.html',
  styleUrls: ['./loginModal.component.scss']
})
export class LoginModalComponent { 

  formRegister: FormGroup;
  phoneWithWhats=false; 

  constructor(
    private dialogRef: MatDialogRef<LoginModalComponent>,
    private formBuilder: FormBuilder,
    private service: ServiceComponent, 
    ){
    this.formRegister = this.formBuilder.group({
      name: ['', Validators.required],
      phone: ['', Validators.required],
      email: ['', Validators.required],
      password: ['',Validators.required]   
    });
  }

  get form() {
    return this.formRegister.controls;
  }

  isPhoneWithWhats() { 
   if(this.phoneWithWhats){  
      this.phoneWithWhats = false; 
   }else{
     this.phoneWithWhats = true; 
   }    
  }  
  
  addUser(){
     if(this.formRegister.valid){

      let user = {
         "name": this.form.name.value, 
         "phone" : this.form.phone.value,
         "phoneWithWhats" :  this.phoneWithWhats,
         "email" : this.form.email.value,
         "password" : this.form.password.value
      }
      
      this.service.addUser(user).subscribe(
            (data:any)=> {
                console.log(data);
                this.dialogRef.close();  
            },
            error => {
                console.log(error);
            });
    }
  }


  close() {
    //**TO DO: Pedir confirmação antes!! 
    this.dialogRef.close();
  }

  sendPassWord(){
    alert("A senha foi enviada para o email tal");
  }

}

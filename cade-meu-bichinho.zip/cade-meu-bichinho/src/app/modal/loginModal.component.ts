import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDatepickerModule,
         MatNativeDateModule,MatButtonModule,MatButtonToggleModule,
         MatIconModule,MatIconRegistry,MatTooltipModule} 
         from '@angular/material'; 
import {DomSanitizer} from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import {FormControl} from '@angular/forms';


@Component({
  selector: 'login-modal',
  templateUrl: './loginModal.component.html',
  styleUrls: ['./loginModal.component.scss']
})
export class LoginModalComponent { 

  constructor(
    private dialogRef: MatDialogRef<LoginModalComponent>) {      
  }
  
  save() { 
    this.dialogRef.close();
  }

  close() {
    //**TO DO: Pedir confirmação antes!! 
    this.dialogRef.close();
  }
}

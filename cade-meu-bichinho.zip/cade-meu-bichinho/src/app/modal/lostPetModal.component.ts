import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef,MatDatepickerModule,
MatNativeDateModule} from '@angular/material';


@Component({
  selector: 'lost-pet-modal',
  templateUrl: './lostPetModal.component.html',
})
export class LostPetModalComponent {
  description: string;

  constructor(
    private dialogRef: MatDialogRef<LostPetModalComponent>,
  ) {}

  save() {
    this.dialogRef.close();
  }

  close() {
    this.dialogRef.close();
  }
}

import { Injectable } from '@angular/core';
import {HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class ServiceComponent {

  backendUrl = "http://localhost:8086/cademeubichinho/";
  tokenForClient = "Basic Z2xvYmFsOjEyMzQ1Ng==";

  constructor(private http: HttpClient) {}


  authentication(username:string,password:string){
      const url = this.backendUrl + "oauth/token?grant_type=password&username="+ username +"&password=" + password;
      return this.http.post(url,null);
  }

  refreshToken(refreshtoken: string){
      const url = this.backendUrl + "oauth/token?refresh_token=" + refreshtoken + "&grant_type=refresh_token";
      return this.http.post(url,null);
  }

  addUser(data: object){
      const url = this.backendUrl + "user/add";
      return this.http.post(url,data);
  }

  addNewPassword(data: object){
      const url = this.backendUrl + "user/add/password/new";
      return this.http.post(url,data);
  }

  getUserLoggedIn(){
      const url = this.backendUrl + "user/loggedIn";
      return this.http.get(url);
  }



  addPet(data: object){
      const url = this.backendUrl + "pet/add";
      return this.http.post(url,data);
  }

  getAllPets(){
      const url = this.backendUrl + "pet/all";
      return this.http.get(url);
  }

  petSearch(data: object){
      const url = this.backendUrl + "pet/search";
      return this.http.post(url,data);
  }

  removePet(id:number,reason:number){
      const url = this.backendUrl + "remove/" + id + "/reason/" + reason;
      return this.http.post(url,null);
  }



  addComment(data: object){
      const url = this.backendUrl + "comment/add";
      return this.http.post(url,data);
  }

  getCommentsWithNotificationsActive(){
      const url = this.backendUrl + "comment/notification/active/asc";
      return this.http.get(url);
  }
  
  
}
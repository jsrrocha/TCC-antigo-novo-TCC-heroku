import { Injectable } from '@angular/core';
import {HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class ServiceComponent {
  
  backendUrl = "http://localhost:8086/cademeubichinho/";
  constructor(private http: HttpClient) {}


  addPet(data: object){
      const url = this.backendUrl + "pet/add";
      return this.http.post(url,data);
  }
  
}
/// <reference types="@types/googlemaps" />
import { Component, ElementRef, NgZone, OnInit, ViewChild,AfterViewInit } from '@angular/core';
import { MapsAPILoader } from '@agm/core';
import {ScrollDispatchModule} from '@angular/cdk/scrolling';
import {DomSanitizer} from '@angular/platform-browser';;
import {DateAdapter, MAT_DATE_FORMATS,MAT_DATE_LOCALE} from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import {FormBuilder,FormControl, FormGroup,Validators} from '@angular/forms';

//material
import { MatDialog, MatDialogConfig,MatRadioModule,MatNativeDateModule,MatDividerModule,
MatListModule,MatPaginatorModule } from '@angular/material';


// Components
import { LostPetModalComponent } from './modal/lostPet/lostPetModal.component';
import { FoundPetModalComponent } from './modal/foundPet/foundPetModal.component';
import { LoginModalComponent } from './modal/login/loginModal.component';
import { CommentModalComponent } from './modal/comment/commentModal.component';
import { ServiceComponent } from './service.component';


export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY',
  },
};


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})
export class AppComponent implements OnInit {
  title = 'tcc';
  lat: number = -30.0513678; // default Porto Alegre
  lng: number = -51.2160819; // default Porto Alegre
  zoom: number = 13;
  searchControl: FormControl;
  loading: boolean = true;
  streetViewControlOptions: object = {}
  zoomControlOptions: object = {}
  
  showSelectedResult = false;
  showNotifications = false;
  pets: Object = [];
  existPets = false;
  name: string = '';
  formLocal: FormGroup;
  formSelectedResult: FormGroup;
  dateResult: Date;

  @ViewChild('search')
  public searchElementRef: ElementRef;


  constructor(
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,
    private dialog: MatDialog,
    private service: ServiceComponent,
    private formBuilder: FormBuilder,
    ){
  
    this.formLocal = this.formBuilder.group({
      searchValue: [''],
    });

  }

  ngOnInit() {
    let self = this;

    // get user geolocation
    navigator.geolocation.getCurrentPosition((position) => {
      self.lat = position.coords.latitude;
      self.lng = position.coords.longitude;
      self.loading = false;
    }, () => {}, { enableHighAccuracy: true });

   

    // MAPS API loader
    this.mapsAPILoader.load().then(() => {
      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        types: ['address']
      });

      // Set input autocomplete
      autocomplete.addListener('place_changed', () => {
        this.ngZone.run(() => {
          // get the place result
          let place: google.maps.places.PlaceResult = autocomplete.getPlace();

          // verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }

          // set latitude, longitude and zoom
          this.lat = place.geometry.location.lat();
          this.lng = place.geometry.location.lng();
          this.zoom = 16;
        });
      });

      // Set map options
      self.streetViewControlOptions = {
        position: google.maps.ControlPosition.RIGHT_BOTTOM
      }
      self.zoomControlOptions = {
        position: google.maps.ControlPosition.RIGHT_BOTTOM
      }
    });
  }

  // Set date of day 
  date = new FormControl(new Date()); 
  serializedDate = new FormControl((new Date()).toISOString());

  //** ANALISAR DE BUSCAR SEM NENHUMA DATA! 
  
  openDialogLostPet() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '520px';
    dialogConfig.height = '570px'

    this.dialog.open(LostPetModalComponent, dialogConfig);
  }

  openDialogFoundPet() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '520px';
    dialogConfig.height = '570px'


    this.dialog.open(FoundPetModalComponent, dialogConfig);
  }

  openDialogLogin() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '500px';
    dialogConfig.height = '400px'; 

    this.dialog.open(LoginModalComponent, dialogConfig);
  }
 
  openDialogComment() { 
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '400px';
    dialogConfig.height = '500px'; 

    this.dialog.open(CommentModalComponent, dialogConfig);
  }

  clearLocal() {
    this.formLocal.controls.searchValue.setValue('');
  }

  inSelectedResult(e,v) {   
    this.showSelectedResult = true; 

    setTimeout(()=>{  
      this.fillResult(v);
    }, 50);
  }

  fillResult(v){
   (<HTMLInputElement>document.getElementById('resultName')
   ).textContent = 
   v[0].value.name;

   if(v[0].value.specie == "DOG"){
      (<HTMLInputElement>document.getElementById('resultSpecie')
     ).textContent = "Cachorro";
   }else{
    (<HTMLInputElement>document.getElementById('resultSpecie')
     ).textContent = "Gato";
   }

   if(v[0].value.sex == "MALE"){
      (<HTMLInputElement>document.getElementById('resultSex')
     ).textContent = "Macho";
   }else{
    (<HTMLInputElement>document.getElementById('resultSex')
     ).textContent = "Fêmea";
   }

   if(v[0].value.lostPet){

      this.dateResult = new Date(v[0].value.date);
      

      (<HTMLInputElement>document.getElementById('resultDate')
     ).textContent = "Perdido dia " + this.dateResult;
   }else{
   (<HTMLInputElement>document.getElementById('resultDate')
     ).textContent = "Encontrado dia " + this.dateResult;
   }

  }


  hiddenSelectedResult(){
    this.showSelectedResult = false; 
  }

  openNotifications() { 
   if(this.showNotifications){  
      this.showNotifications = false; 
   }else{
     this.showNotifications = true; 
   }
  }

  getAllPets(){
    this.service.getAllPets().subscribe(
        (data:any)=> {
            console.log(data); 
            this.pets = data;
            this.existPets = true;
        },
        error => {
            console.log(error);
        });
  }

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import {DomSanitizer} from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import {ScrollDispatchModule} from '@angular/cdk/scrolling'; 

// Map
import { AgmCoreModule } from '@agm/core';

// Components
import { LostPetModalComponent } from './modal/lostPetModal.component';
import { FoundPetModalComponent } from './modal/foundPetModal.component';
import { LoginModalComponent } from './modal/loginModal.component';



// Material
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
   MatButtonModule,
   MatCheckboxModule,
   MatGridListModule,
   MatInputModule,
   MatIconModule,
   MatCardModule,
   MatMenuModule,
   MatDialogModule,
   MatDatepickerModule,
   MatNativeDateModule,
   MatButtonToggleModule,
   MatTooltipModule,
   MatRadioModule,
   MatDividerModule,
   MatListModule,
   MatPaginatorModule
 } from '@angular/material';
 
@NgModule({
  declarations: [
    AppComponent,
    LostPetModalComponent,
    FoundPetModalComponent,
    LoginModalComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    // material
    MatButtonModule,
    MatCheckboxModule,
    MatGridListModule,
    MatInputModule,
    MatIconModule,
    MatCardModule,
    MatMenuModule,
    MatDialogModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatButtonToggleModule,
    MatTooltipModule,
    MatRadioModule,
    MatDividerModule,
    MatListModule,
    MatPaginatorModule,
    ScrollDispatchModule,
    // map
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyClNvzWYjAplvnnhCGHaXzVEiV6KGEHYSQ',
      libraries: ['places']
    })
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [LostPetModalComponent, FoundPetModalComponent,LoginModalComponent]
})
export class AppModule { }


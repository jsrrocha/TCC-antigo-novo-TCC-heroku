import { Injectable } from '@angular/core';
import {HttpRequest,HttpHandler,HttpEvent,HttpInterceptor} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from "rxjs/BehaviorSubject";

import { LoginModalComponent } from './modal/login/loginModal.component';
import { ServiceComponent } from './service.component';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  constructor(
    public service: ServiceComponent,
    public login: LoginModalComponent,
  ) {}

  expiresIn = parseInt(localStorage.getItem('expiresIn'));
  expireTime = new Date().getTime() + 20 * 10000; // ****CHANGE TO EXPIRE IN!! THIS IS FOR TEST

  //expiresIn is not defi..

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if(new Date().getTime() >= this.expireTime){
        this.expireTime = new Date().getTime() + 20 * 1000;
        //this.login.refreshAccessAuth();
    }

    var authToken = localStorage.getItem('token');
    
    request = request.clone({
      setHeaders: {
        Authorization:localStorage.getItem('token').toString()
      }
    });

    return next.handle(request);
  }

}

package com.tcc.CadeMeuBichinho.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.tcc.CadeMeuBichinho.model.Comment;

public interface CommentRepository extends CrudRepository<Comment, Long>{ 
	public List<Comment> findByNotificationActiveOrderByIdAsc(Boolean notificationActive);
}

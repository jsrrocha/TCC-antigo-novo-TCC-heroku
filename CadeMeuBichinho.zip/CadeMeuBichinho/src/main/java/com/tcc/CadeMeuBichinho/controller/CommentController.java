package com.tcc.CadeMeuBichinho.controller;


import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcc.CadeMeuBichinho.Repository.CommentRepository;
import com.tcc.CadeMeuBichinho.model.Comment;

@RestController
@RequestMapping("comment")
public class CommentController {
	
	@Autowired
	CommentRepository commentRepository;

	@PostMapping("")
	public ResponseEntity<?> addComment(@RequestBody Comment comment){
		try {
			commentRepository.save(comment);
			return new ResponseEntity<Comment>(comment, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> get(@PathVariable Long id){
		try {
			Optional<Comment> getComment= commentRepository.findById(id);
			return new ResponseEntity<Optional<Comment>>(getComment, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}
	
	@GetMapping("/all/asc")
	public ResponseEntity<?> getAllAsc(){
		try {
			Iterable<Comment> list = commentRepository.findAllByOrderByIdAsc();
			return new ResponseEntity<>(list, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}

}

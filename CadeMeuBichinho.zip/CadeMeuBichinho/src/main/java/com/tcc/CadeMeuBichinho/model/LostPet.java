package com.tcc.CadeMeuBichinho.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LostPet")
public class LostPet {
	@Id 
	@GeneratedValue
	private Long id; 
	private String name;
	private Types type;
	private Sex sex;
	private Size size;
	private FurColor furColor;
	private LifeStages lifeStage;
	private byte[] photo;
	private Date dateLost;
	private Integer latitudeLost;
	private Integer longitudeLost;
	private Integer phone;
	private Boolean phoneWithWhats;
	private String description;
	
	public LostPet() {
	}

	public LostPet(String name, Types type, Sex sex, byte[] photo, Date dateLost, Size size, FurColor furCOlor,
			LifeStages lifeStage, Integer latitudeLost, Integer longitudeLost, Integer phone, Boolean phonewithWhats,
			String description) {
		super();
		this.name = name;
		this.type = type;
		this.sex = sex;
		this.photo = photo;
		this.dateLost = dateLost;
		this.size = size;
		this.furColor = furCOlor;
		this.lifeStage = lifeStage;
		this.latitudeLost = latitudeLost;
		this.longitudeLost = longitudeLost;
		this.phone = phone;
		this.phoneWithWhats = phonewithWhats;
		this.description = description;
	}
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Types getType() {
		return type;
	}

	public void setType(Types type) {
		this.type = type;
	}

	public Sex getSex() {
		return sex;
	}

	public void setSex(Sex sex) {
		this.sex = sex;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	public Date getDateLost() {
		return dateLost;
	}

	public void setDateLost(Date dateLost) {
		this.dateLost = dateLost;
	}

	public Size getSize() {
		return size;
	}

	public void setSize(Size size) {
		this.size = size;
	}

	public FurColor getFurCOlor() {
		return furColor;
	}

	public void setFurCOlor(FurColor furCOlor) {
		this.furColor = furCOlor;
	}

	public LifeStages getLifeStage() {
		return lifeStage;
	}

	public void setLifeStage(LifeStages lifeStage) {
		this.lifeStage = lifeStage;
	}

	public Integer getLatitudeLost() {
		return latitudeLost;
	}

	public void setLatitudeLost(Integer latitudeLost) {
		this.latitudeLost = latitudeLost;
	}

	public Integer getLongitudeLost() {
		return longitudeLost;
	}

	public void setLongitudeLost(Integer longitudeLost) {
		this.longitudeLost = longitudeLost;
	}

	public Integer getPhone() {
		return phone;
	}

	public void setPhone(Integer phone) {
		this.phone = phone;
	}

	public Boolean getPhonewithWhats() {
		return phoneWithWhats;
	}

	public void setPhonewithWhats(Boolean phonewithWhats) {
		this.phoneWithWhats = phonewithWhats;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public enum Types {
		   DOG,CAT
	} 
	public enum Sex {
		 MALE,FEMALE 
		} 
	public enum Size {
		   P,M,G,GG	
    } 
	
	public enum FurColor {
		BRIGHT,DARK,TABBLY,WithPolkaDots	
    } 
	
	public enum LifeStages {
		PUPPY,ADULT,OLD
    } 
	
}

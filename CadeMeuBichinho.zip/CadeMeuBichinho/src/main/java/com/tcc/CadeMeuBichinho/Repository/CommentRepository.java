package com.tcc.CadeMeuBichinho.Repository;

import org.springframework.data.repository.CrudRepository;

import com.tcc.CadeMeuBichinho.model.Comment;

public interface CommentRepository extends CrudRepository<Comment, Long>{ 

}

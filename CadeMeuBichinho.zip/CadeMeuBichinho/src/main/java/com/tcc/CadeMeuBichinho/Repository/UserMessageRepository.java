package com.tcc.CadeMeuBichinho.Repository;

import org.springframework.data.repository.CrudRepository;
import com.tcc.CadeMeuBichinho.model.UserMessage;

public interface UserMessageRepository extends CrudRepository<UserMessage, Long>{

}

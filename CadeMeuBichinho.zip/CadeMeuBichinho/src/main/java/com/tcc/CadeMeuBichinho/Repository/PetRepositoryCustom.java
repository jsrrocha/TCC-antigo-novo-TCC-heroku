package com.tcc.CadeMeuBichinho.Repository;

public interface PetRepositoryCustom {

}

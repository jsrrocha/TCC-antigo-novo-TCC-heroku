package com.tcc.CadeMeuBichinho.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.tcc.CadeMeuBichinho.Repository.UserMessageRepository;
import com.tcc.CadeMeuBichinho.model.UserMessage;

@RestController
@RequestMapping("user/message")
public class UserMessageController {
	@Autowired
	UserMessageRepository userMessageRepository;

	@PostMapping("")
	public ResponseEntity<?> adduserMessage(@RequestBody UserMessage userMessage){
		try {
			userMessageRepository.save(userMessage);
			return new ResponseEntity<UserMessage>(userMessage, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> get(@PathVariable Long id){
		try {
			Optional<UserMessage> getuserMessage = userMessageRepository.findById(id);
			return new ResponseEntity<Optional<UserMessage>>(getuserMessage, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}
	
	@GetMapping("/all")
	public ResponseEntity<?> getAll(){
		try {
			Iterable<UserMessage> list = userMessageRepository.findAll();
			return new ResponseEntity<>(list, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}
}

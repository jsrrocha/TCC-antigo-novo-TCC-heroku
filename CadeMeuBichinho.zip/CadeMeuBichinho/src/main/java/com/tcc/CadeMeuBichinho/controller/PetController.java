package com.tcc.CadeMeuBichinho.controller;

//import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.tcc.CadeMeuBichinho.Repository.PetRepository;
import com.tcc.CadeMeuBichinho.model.Pet;

@RestController
@RequestMapping("pet")
public class PetController { 

	@Autowired
	PetRepository petRepository;

	@PostMapping("")
	public ResponseEntity<?> addPet(@RequestBody Pet pet){
		try {
			petRepository.save(pet);
			return new ResponseEntity<Pet>(pet, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> getPet(@PathVariable Long id){
		try {
			Optional<Pet> getPet = petRepository.findById(id);
			return new ResponseEntity<Optional<Pet>>(getPet, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}

	@GetMapping("/all")
	public ResponseEntity<?> getAll(){
		try {
			Iterable<Pet> list = petRepository.findAll();
			return new ResponseEntity<>(list, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}
	
	@GetMapping("/lost")
	public ResponseEntity<?> getLostPet(){
		try {
			Iterable<Pet> list = petRepository.findByLostPet(true);
			return new ResponseEntity<>(list, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}
	
	@GetMapping("/find")
	public ResponseEntity<?> getFindPet(){
		try {
			Iterable<Pet> list = petRepository.findByLostPet(false);
			return new ResponseEntity<>(list, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}

}

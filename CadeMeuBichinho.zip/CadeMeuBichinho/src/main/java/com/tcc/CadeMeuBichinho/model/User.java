package com.tcc.CadeMeuBichinho.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "User")
public class User {
	@Id 
	@GeneratedValue
	private Long id; 
	private String name;
	private String email;
	private String senha;
	private String phone;
	private Boolean phoneWhats;
	
	public User() {
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Boolean getPhoneWhats() {
		return phoneWhats;
	}
	public void setPhoneWhats(Boolean phoneWhats) {
		this.phoneWhats = phoneWhats;
	}
	
	
	

	//Pattern p = Pattern.compile(".+@.+\\.[a-z]+");
    //Matcher m = p.matcher(email);
	
	//https://www.guj.com.br/t/criptografar-senha/131388/6
}

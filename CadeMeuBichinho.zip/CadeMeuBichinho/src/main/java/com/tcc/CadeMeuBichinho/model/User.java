package com.tcc.CadeMeuBichinho.model;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;

@Entity
@Table(name = "Users")
public class User {
	@Id 
	@GeneratedValue
	private Long id; 
	private String name;
	@Email
	private String email;
	private String password;
	private String phone;
	private Boolean phoneWhats;
	@OneToMany(cascade = CascadeType.ALL)
	private List<Pet> pet;
	@OneToMany(mappedBy = "userSend",cascade = CascadeType.ALL) 
	private List<Comment> messagesSend;
	@OneToMany(mappedBy = "userReceived",cascade = CascadeType.ALL)
	private List<Comment> messagesReceived;
	
	
	public User() {
	}
	

	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPassword() {
		
		return password;
	}

	public void setPassword(String password) throws NoSuchAlgorithmException {
		
		MessageDigest digest = MessageDigest.getInstance("SHA-1");
		digest.update(password.getBytes());
		byte[] bytes = digest.digest();
		//BASE64 encoder = new BASE64Encoder();
		//String senhaCodificada = encoder.encode(bytes);
		
		String passwordCodification = Base64.getEncoder().encodeToString(bytes);
		
		System.out.println("Senha     : " + password);
		System.out.println("Senha SHA1: " + passwordCodification);
		
		this.password = password;
	}

	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Boolean getPhoneWhats() {
		return phoneWhats;
	}
	public void setPhoneWhats(Boolean phoneWhats) {
		this.phoneWhats = phoneWhats;
	}


	public List<Pet> getPet() {
		return pet;
	}


	public void setPet(List<Pet> pet) {
		this.pet = pet;
	}


	public List<Comment> getMessagesSend() {
		return messagesSend;
	}


	public void setMessagesSend(List<Comment> messagesSend) {
		this.messagesSend = messagesSend;
	}


	public List<Comment> getMessagesReceived() {
		return messagesReceived;
	}


	public void setMessagesReceived(List<Comment> messagesReceived) {
		this.messagesReceived = messagesReceived;
	}

	
}

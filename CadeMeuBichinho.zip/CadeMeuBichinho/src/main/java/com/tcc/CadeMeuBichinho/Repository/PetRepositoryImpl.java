package com.tcc.CadeMeuBichinho.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.tcc.CadeMeuBichinho.model.Pet;
import com.tcc.CadeMeuBichinho.model.Pet.Types;

@Repository
public class PetRepositoryImpl implements PetRepositoryCustom{
	@PersistenceContext
	EntityManager em;
	
	@Override
	public List<Pet> findBySearchTerms(Map<String, String> criteria_list) {
		
		CriteriaBuilder cb = em.getCriteriaBuilder();
	    CriteriaQuery<Pet> cq = cb.createQuery(Pet.class); 
	 
	    Root<Pet> pet = cq.from(Pet.class); 
	    List<Predicate> predicates = new ArrayList<>();
	    
	    
	    
	    for (Map.Entry<String, String> entry : criteria_list.entrySet()) {
	    	
	    	predicates.add(cb.equal(pet.get(entry.getKey()),Types.DOG));
	    	System.out.println("AQUI " + predicates.toString());
	  	}	
	    
	     
	   // if (authorName != null) {
	        //predicates.add(cb.equal(book.get("author"), authorName));
	   // }
	    //if (title != null) {
	        //predicates.add(cb.like(book.get("title"), "%" + title + "%"));
	    //}
	    //cq.where(predicates.toArray(new Predicate[0]));
	    
	    cq.where(predicates.toArray(new Predicate[0]));
    	System.out.println(cq.getGroupList());
    	System.out.println(cq.getParameters());
	 
	    return em.createQuery(cq).getResultList();
	}
	
	
	//https://www.baeldung.com/spring-data-criteria-queries
	//https://bitbucket.org/mwolfart/sistema-patas-dadas
}

package com.tcc.CadeMeuBichinho.Repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Repository;

import com.tcc.CadeMeuBichinho.model.Pet;
import com.tcc.CadeMeuBichinho.model.Pet.FurColor;
import com.tcc.CadeMeuBichinho.model.Pet.LifeStages;
import com.tcc.CadeMeuBichinho.model.Pet.RemovalReason;
import com.tcc.CadeMeuBichinho.model.Pet.Sex;
import com.tcc.CadeMeuBichinho.model.Pet.Size;
import com.tcc.CadeMeuBichinho.model.Pet.Type;

@Repository
public class PetRepositoryImpl implements PetRepositoryCustom{
	@PersistenceContext
	EntityManager em;
	
	@Override
	public List<Pet> findBySearchTerms(Map<String, String> petMap) {
		
		CriteriaBuilder cb = em.getCriteriaBuilder();
	    CriteriaQuery<Pet> cq = cb.createQuery(Pet.class); 
	 
	    Root<Pet> pet = cq.from(Pet.class); 
	    List<Predicate> predicates = new ArrayList<>();
	    
	    if(petMap.get("type") != null) {
	    	Integer index = Integer.parseInt(petMap.get("type").toString());	    	
	    	Type type = Type.values()[index];  
	    	predicates.add(cb.equal(pet.get("type"),type));	
	    }
	    
	    if(petMap.get("sex") != null) {
	    	Integer index = Integer.parseInt(petMap.get("sex").toString());	    	
			Sex sex = Sex.values()[index];  
	    	predicates.add(cb.equal(pet.get("sex"),sex));
	    }
	    
	    if(petMap.get("size") != null) {
	    	Integer index = Integer.parseInt(petMap.get("size").toString());	    	
			Size size = Size.values()[index];  
    		predicates.add(cb.equal(pet.get("size"),size));
	    }
	    
	    if(petMap.get("furColor") != null) {
	    	Integer index = Integer.parseInt(petMap.get("furColor").toString());	    	
			FurColor fur = FurColor.values()[index];  
    		predicates.add(cb.equal(pet.get("furColor"),fur));
    		
	    }
	    
	    if(petMap.get("lifeStages") != null) {
	    	Integer index = Integer.parseInt(petMap.get("lifeStages").toString());	    	
			LifeStages lifeStage = LifeStages.values()[index];  
    		predicates.add(cb.equal(pet.get("lifeStages"),lifeStage));
	    }
	    
	    if(petMap.get("removalReason") != null) {
	    	Integer index = Integer.parseInt(petMap.get("removalReason").toString());	    	
			RemovalReason removalReason = RemovalReason.values()[index];  
    		predicates.add(cb.equal(pet.get("removalReason"),removalReason));
	    }
	    
	    //testar enviando uma imagem..
	    if(petMap.get("photo") != null) {
	    	byte[] backToBytes = Base64.decodeBase64(petMap.get("photo").toString());
    		predicates.add(cb.equal(pet.get("photo"),backToBytes));

	    }
	    
	    if(petMap.get("date") != null) {
		    Date date = new Date(Long.parseLong(petMap.get("date").toString()));
    		predicates.add(cb.equal(pet.get("date"),date));

	    }
	    
	    if(petMap.get("description") != null) {
    		predicates.add(cb.equal(pet.get("description"),petMap.get("description").toString()));
	    }
	    
	    if(petMap.get("latitude") != null) {
	    	Integer latitude = Integer.parseInt(petMap.get("latitude").toString());
    		predicates.add(cb.equal(pet.get("latitude"),latitude)); 
	    }
	    
	    if(petMap.get("longitude") != null) {
	    	Integer longitude = Integer.parseInt(petMap.get("longitude").toString());
    		predicates.add(cb.equal(pet.get("longitude"),longitude)); 
	    }
	    
	    if(petMap.get("phone") != null) {
	    	Integer phone = Integer.parseInt(petMap.get("phone").toString());
    		predicates.add(cb.equal(pet.get("phone"),phone)); 
	    }
	    
	    if(petMap.get("phoneWithWhats") != null) {
	    	Boolean phoneWithWhats  = Boolean.valueOf(petMap.get("phoneWithWhats").toString());
    		predicates.add(cb.equal(pet.get("phoneWithWhats"),phoneWithWhats)); 

	    }
	    
	    if(petMap.get("lostPet") != null) {
	    	Boolean lostPet  = Boolean.valueOf(petMap.get("lostPet").toString());
    		predicates.add(cb.equal(pet.get("lostPet"),lostPet)); 

	    }
	    
	    if(petMap.get("remove") != null) {
	    	Boolean remove  = Boolean.valueOf(petMap.get("remove").toString());
    		predicates.add(cb.equal(pet.get("remove"),remove)); 
	    }
	        
	    //for (Map.Entry<String, String> entry : petMap.entrySet()) {		
	    	//predicates.add(cb.equal(pet.get(entry.getKey()),Types.DOG));	    	
	  	//}
	    
	    cq.where(predicates.toArray(new Predicate[0]));
	    return em.createQuery(cq).getResultList();
	}
	
	
	//https://www.baeldung.com/spring-data-criteria-queries
	//https://bitbucket.org/mwolfart/sistema-patas-dadas
}

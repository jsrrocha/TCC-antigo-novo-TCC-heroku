package com.tcc.CadeMeuBichinho.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.tcc.CadeMeuBichinho.model.Pet;

@Repository
public class PetRepositoryImpl implements PetRepositoryCustom{

	EntityManager em;
	
	@Override
	public List<Pet> findBySearchTerms(Map<String, String> criteria_list) {
		
		CriteriaBuilder cb = em.getCriteriaBuilder();
	    CriteriaQuery<Pet> cq = cb.createQuery(Pet.class); 
	 
	    Root<Pet> pet = cq.from(Pet.class); 
	    List<Predicate> predicates = new ArrayList<>();
	    
	    for (Map.Entry<String, String> entry : criteria_list.entrySet()) {
	    	predicates.add(cb.equal(pet.get(entry.getKey()),entry.getValue()));
	    	
	    	//document.put("metadata_" + entry.getKey(), (String) entry.getValue());	
		}	
	    
	     
	   // if (authorName != null) {
	        //predicates.add(cb.equal(book.get("author"), authorName));
	   // }
	    //if (title != null) {
	        //predicates.add(cb.like(book.get("title"), "%" + title + "%"));
	    //}
	    //cq.where(predicates.toArray(new Predicate[0]));
	 
	    return em.createQuery(cq).getResultList();
	}
	
	
	//https://www.baeldung.com/spring-data-criteria-queries
	//https://bitbucket.org/mwolfart/sistema-patas-dadas
}

package com.tcc.CadeMeuBichinho.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "UserMessage")
public class UserMessage {
	@Id 
	@GeneratedValue
	private Long id; 
	private User userSent;
	private User userReceived;
	private String message;
	private Pet pet;
	
	public UserMessage() {
		
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUserSent() {
		return userSent;
	}
	public void setUserSent(User userSent) {
		this.userSent = userSent;
	}
	public User getUserReceived() {
		return userReceived;
	}
	public void setUserReceived(User userReceived) {
		this.userReceived = userReceived;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Pet getPet() {
		return pet;
	}
	public void setPet(Pet pet) {
		this.pet = pet;
	}
	
	
	
	
}

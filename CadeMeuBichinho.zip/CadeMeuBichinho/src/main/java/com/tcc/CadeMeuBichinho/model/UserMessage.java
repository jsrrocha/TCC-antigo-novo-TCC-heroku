package com.tcc.CadeMeuBichinho.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "UsersMessage")
public class UserMessage {
	@Id 
	@GeneratedValue
	private Long id;
	@ManyToOne(cascade = CascadeType.ALL)
	private User userSent;
	@ManyToOne(cascade = CascadeType.ALL)
	private User userReceived;
	@ManyToOne(cascade = CascadeType.ALL)
	private Pet pet;
	private String message;
	
	public UserMessage() {
		
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUserSent() {
		return userSent;
	}
	public void setUserSent(User userSent) {
		this.userSent = userSent;
	}
	public User getUserReceived() {
		return userReceived;
	}
	public void setUserReceived(User userReceived) {
		this.userReceived = userReceived;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Pet getPet() {
		return pet;
	}
	public void setPet(Pet pet) {
		this.pet = pet;
	}
	
	
	
	
}

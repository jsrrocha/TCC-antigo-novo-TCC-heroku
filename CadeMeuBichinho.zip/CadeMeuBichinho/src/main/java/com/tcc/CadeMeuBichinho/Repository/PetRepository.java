package com.tcc.CadeMeuBichinho.Repository;

import org.springframework.data.repository.CrudRepository;

import com.tcc.CadeMeuBichinho.model.Pet;

public interface PetRepository extends CrudRepository<Pet, Long>,PetRepositoryCustom {
/*
	@Override
	List<Book> findBooksByAuthorNameAndTitle(String authorName, String title) {
	    CriteriaBuilder cb = em.getCriteriaBuilder();
	    CriteriaQuery<Book> cq = cb.createQuery(Book.class); 
	 
	    Root<Book> book = cq.from(Book.class);
	    List<Predicate> predicates = new ArrayList<>();
	     
	    if (authorName != null) {
	        predicates.add(cb.equal(book.get("author"), authorName));
	    }
	    if (title != null) {
	        predicates.add(cb.like(book.get("title"), "%" + title + "%"));
	    }
	    cq.where(predicates.toArray(new Predicate[0]));
	 
	    return em.createQuery(cq).getResultList();
	}
	*/
	
	//https://www.baeldung.com/spring-data-criteria-queries
	//https://bitbucket.org/mwolfart/sistema-patas-dadas
}

package com.tcc.CadeMeuBichinho.model.auth;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Size;

@Entity
//@Table(name="oauthClientDetails")
public class OauthClientDetails{


  @Id
  private String clientId;

  @Size(min = 0, max = 500)
  private String clientSecret;

  @Size(min = 0, max = 500)
  private String authorizedGrantTypes;

  @Size(min = 0, max = 500)
  private String scope;

  @Size(min = 0, max = 500)
  private String resourceIds; //resouces
  
  private Integer accessTokenValidity; 
  private Integer refreshTokenValidity; 
  
  private String webServerRedirectUri;
  private String autoapprove;
  private String authorities;  
  private String additionalInformation;  


  public OauthClientDetails() {
  }

  public String getClientId() {
      return clientId;
  }

  public void setClientId(String clientId) {
      this.clientId = clientId;
  }

  public String getClientSecret() {
      return clientSecret;
  }

  public void setClientSecret(String clientSecret) {
      this.clientSecret = clientSecret;
  }
  public String getAuthorizedGrantTypes() {
      return authorizedGrantTypes;
  }

  public void setAuthorizedGrantTypes(String authorizedGrantTypes) {
      this.authorizedGrantTypes = authorizedGrantTypes;
  }

  public String getScope() {
      return scope;
  }

  public void setScope(String scope) {
      this.scope = scope;
  }

  public String getResourceIds() {
      return resourceIds;
  }

  public void setResourceIds(String resourceIds) {
      this.resourceIds = resourceIds;
  }

  public Integer getAccessTokenValidity() {
      return accessTokenValidity;
  }

  public void setAccessTokenValidity(Integer accessTokenValidity) {
      this.accessTokenValidity = accessTokenValidity;
  }

public String getWebServerRedirectUri() {
	return webServerRedirectUri;
}

public void setWebServerRedirectUri(String webServerRedirecturi) {
	this.webServerRedirectUri = webServerRedirecturi;
}

public String getAutoapprove() {
	return autoapprove;
}

public void setAutoapprove(String autoapprove) {
	this.autoapprove = autoapprove;
}

public String getAuthorities() {
	return authorities;
}

public void setAuthorities(String authorities) {
	this.authorities = authorities;
}

public Integer getRefreshTokenValidity() {
	return refreshTokenValidity;
}

public void setRefreshTokenValidity(Integer refreshTokenValidity) {
	this.refreshTokenValidity = refreshTokenValidity;
}

public String getAdditionalInformation() {
	return additionalInformation;
}

public void setAdditionalInformation(String additionalInformation) {
	this.additionalInformation = additionalInformation;
}
  
  

}

package com.tcc.CadeMeuBichinho.controller;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.tcc.CadeMeuBichinho.Repository.UserRepository;
import com.tcc.CadeMeuBichinho.model.User;

@RestController
@RequestMapping("user")
public class UserController {
	@Autowired
	UserRepository userRepository;

	@PostMapping("")
	public ResponseEntity<?> adduser(@RequestBody User user){
		try {
			
			Pattern pattern = Pattern.compile(".+@.+\\.[a-z]+");
		    Matcher matcher = pattern.matcher(user.getEmail());
		    if(!matcher.matches()) {
				return new ResponseEntity<>("Insira um email válido", HttpStatus.BAD_REQUEST); 
		    }
		    
			userRepository.save(user);
			return new ResponseEntity<User>(user, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> get(@PathVariable Long id){
		try {
			Optional<User> getuser = userRepository.findById(id);
			return new ResponseEntity<Optional<User>>(getuser, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}
	
	@GetMapping("/all")
	public ResponseEntity<?> getAll(){
		try {
			Iterable<User> list = userRepository.findAll();
			return new ResponseEntity<>(list, HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e, HttpStatus.BAD_REQUEST); 
		}
	}
}

/// <reference types="@types/googlemaps" />
import { Component, ElementRef, NgZone, OnInit, ViewChild } from '@angular/core';
import { MapsAPILoader } from '@agm/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatDialogConfig } from '@angular/material';

// Components
import { LostPetModalComponent } from './modal/lostPetModal.component';
import { FoundPetModalComponent } from './modal/foundPetModal.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'tcc';
  lat: number = -30.0513678; // default Porto Alegre
  lng: number = -51.2160819; // default Porto Alegre
  zoom: number = 13;
  searchValue: string = '';
  searchControl: FormControl;
  loading: boolean = true;
  streetViewControlOptions: object = {}
  zoomControlOptions: object = {}

  @ViewChild('search')
  public searchElementRef: ElementRef;

  constructor(
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,
    private dialog: MatDialog,
  ) {}

  ngOnInit() {
    let self = this;

    // get user geolocation
    navigator.geolocation.getCurrentPosition((position) => {
      self.lat = position.coords.latitude;
      self.lng = position.coords.longitude;
      self.loading = false;
    }, () => {}, { enableHighAccuracy: true });

    // create search FormControl
    this.searchControl = new FormControl();

    // MAPS API loader
    this.mapsAPILoader.load().then(() => {
      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        types: ['address']
      });

      // Set input autocomplete
      autocomplete.addListener('place_changed', () => {
        this.ngZone.run(() => {
          // get the place result
          let place: google.maps.places.PlaceResult = autocomplete.getPlace();

          // verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }

          // set latitude, longitude and zoom
          this.lat = place.geometry.location.lat();
          this.lng = place.geometry.location.lng();
          this.zoom = 16;
        });
      });

      // Set map options
      self.streetViewControlOptions = {
        position: google.maps.ControlPosition.LEFT_BOTTOM
      }
      self.zoomControlOptions = {
        position: google.maps.ControlPosition.LEFT_BOTTOM
      }
    });
  }

  openDialogLostPet() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '400px';

    this.dialog.open(LostPetModalComponent, dialogConfig);
  }

  openDialogFoundPet() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '400px';

    this.dialog.open(FoundPetModalComponent, dialogConfig);
  }
}

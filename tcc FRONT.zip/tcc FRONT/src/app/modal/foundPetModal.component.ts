import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'found-pet-modal',
  templateUrl: './foundPetModal.component.html',
})
export class FoundPetModalComponent {
  description: string;

  constructor(
    private dialogRef: MatDialogRef<FoundPetModalComponent>,
  ) {}

  save() {
    this.dialogRef.close();
  }

  close() {
    this.dialogRef.close();
  }
}
